<?php
	include "views/header.php";
	include "back.php";
	$sql = "SELECT * FROM products";
	$result = $conn->query($sql);
?>
<!DOCTYPE html>
<html>
<head>
	<title>select</title>
	<link rel="stylesheet" type="text/css" href="style.css">
	 <meta charset="UTF-8">
  <link rel="stylesheet" type="text/css" href="./slick/slick.css">
  <link rel="stylesheet" type="text/css" href="./slick/slick-theme.css">
</head>
<body>
	<div class="categories">
		<div class="left">
			<div>
				<img src="views/img/category-1.jpg">
				<h1>Women’s fashion</h1>
			</div>
		</div>
		<div class="right">
			<div>
				<img src="views/img/category-2.jpg">
				<h2>Men’s fashion</h2>
			</div>
			<div>
				<img src="views/img/category-3.jpg">
				<h2>Kid’s fashion</h2>
			</div>
			<div>
				<img src="views/img/category-4.jpg">
				<h2>Cosmetics</h2>
			</div>
			<div>
				<img src="views/img/category-5.jpg">
				<h2>Accessories</h2>
			</div>
		</div>
	</div>
	<form action="back.php" method="post">
		<input type="text" name="name">
		<input type="hidden" name="event" value="category">
		<button>Send</button>

		
	</form>

	

	

</body>
<script src="https://code.jquery.com/jquery-2.2.0.min.js" type="text/javascript"></script>
<script src="./slick/slick.js" type="text/javascript" charset="utf-8"></script>
<script type="text/javascript" src="script.js"></script>
</html>
<?php
	include "views/footer.php";
?>